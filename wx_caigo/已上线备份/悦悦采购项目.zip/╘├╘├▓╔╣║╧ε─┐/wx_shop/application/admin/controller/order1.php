//订单统计
        public function count(){
            $count=db()
            $lst=db('order')->field('*,count(*)')->alias('a')
            ->join('user b','a.user_id=b.id')->where(['a.post_status'=>1])->group('user_id')->select();
            $order=db('order')->alias('a')
            ->join('order_goods b','a.id=b.order_id')->where(['a.post_status'=>1])->select();
            print_r($order);die;
            $goodsInfo['goods_num'] = 0;
            // select count(*) from wx_order GROUP BY user_id ;
            foreach ($order as $k => $v) {
                $goodsInfo['order_id']= $v['id'];
            $goodsInfo['goods_num']+=$v['goods_num'];
            }
            print_r($goodsInfo);die;
        }


        ->paginate(['page'=> $page]);
 ReturnJson($code,$message,$info);

     <!--    select password,checktime,checktype,addtime,city ,levelid,wl.levname,tempA.total
from wx_user  wx
LEFT JOIN wx_level wl ON wl.id=wx.levelid
LEFT JOIN (
SELECT user_id, SUM(order_total_price)total FROM wx_order GROUP BY user_id
)tempA ON wx.id= tempA.user_id
 -->