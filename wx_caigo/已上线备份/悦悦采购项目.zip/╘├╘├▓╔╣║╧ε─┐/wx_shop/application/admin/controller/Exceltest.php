<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;  
use app\admin\model\Excel as ExcelModel;
class Exceltest extends Controller
{
  //产品审核列表
     function downLoadEcle($id){//加入$id
         $data=db('order_goods')->alias('a')
         ->join('order p','p.id=a.order_id')
         ->join('user b','b.id=p.user_id')
        ->where('p.id',$id)//后期改成$id
        ->select();
        $datacount=db('order_goods')->alias('a')
         ->join('order p','p.id=a.order_id')
         ->join('user b','b.id=p.user_id')
        ->where('p.id',$id)->count();
        // print_r($datacount);die;
        $deliverytime=db('Deliverytime')->where('id',$data[0]['deliverytime_id'])->find();
         $table = '';
            $table .= "  <p id='pid'>Hello Html!</p>
            <script type='text/javascript'>
    document.getElementById('pid').innerHTML='绝地反击';//js改变html的内容
</script>
                ";
                echo $table;
    }

//
//产品审核列表
     function downLoadExcle($id){//加入$id
         $data=db('order_goods')->alias('a')
         ->join('order p','p.id=a.order_id')
         ->join('user b','b.id=p.user_id')
        ->where('p.id',$id)//后期改成$id
        ->select();
        $datacount=db('order_goods')->alias('a')
         ->join('order p','p.id=a.order_id')
         ->join('user b','b.id=p.user_id')
        ->where('p.id',$id)->count();
        // print_r($datacount);die;
        $deliverytime=db('Deliverytime')->where('id',$data[0]['deliverytime_id'])->find();
            $table = '';
            $table .= "<table border='1' align='center' >
                    
                ";$first=1;
                $total=0;
            foreach ($data as $key=>$v) {
                $Excel=new ExcelModel();
        $post_times=$Excel->weekday($data[0]['post_time']);
                $firsr=$first++;
                    if($key==0 || $key%15==0){//头部
                $table .= "
                <tr>
                        <td align='center' colspan='6' class='top'>广西悦采农业股份有限公司</td>   
                </tr>
                <tr>
                        <td align='center' colspan='6' class='top'>配送单&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NO:</td>   
                </tr>
                <tr>
                        <td style='text-align:center'  colspan='3' class='top'>客户： {$v['name']}</td>
                        <td align='center' colspan='2' class='top'>{$deliverytime['time']}</td>
                        <td align='center' colspan='1' class='top'>{$post_times}</td>  
                </tr>
                <tr>
                        <td align='center' class='top'>序号</td>
                        <td align='center' class='top'>品种</td>
                        <td align='center' class='top'>单位</td>
                        <td align='center' class='top'>数量</td>
                        <td align='center' class='top'>单价</td>
                        <td align='center' class='top'>金额</td>   
                </tr>";
                    }
                    
                  $v['numprice']=$v['goods_num']*$v['aprice'];
                  $total+=$v['numprice'];//这里是中间的数据
                $table .= "
                <tr>
                        <td align='center' class='name'>{$firsr}</td>
                        <td align='center' class='name'>{$v['goods_name']}</td>
                        <td align='center' class='name'>{$v['unit']}</td>
                        <td align='center' class='name'>{$v['goods_num']}</td>
                        <td align='center' class='name'>{$v['aprice']}</td>
                        <td align='center' class='name'>{$v['numprice']}</td>
                </tr>";
                if($key == 14 || ($key+1)%15 == 0|| $key+1== $datacount){//尾部
                    echo $total;die;
                    $post_timer=date('Y/m/s', $data[0]['post_time']);
                $Excel=new ExcelModel();
                $cateres=$Excel->number2chinese($v['order_total_price']);
                $table .= "
                <tr>
                        <td align='center' class='banner'>总价</td>
                        <td align='center' colspan='3' class='banner'>{$cateres}</td>
                        <td align='center' colspan='2' class='banner'>{$v['total']}</td>    
                </tr>
                <tr>
                        <td align='center' rowspan='2' colspan='1' class='banner'>日期</td>
                        <td align='center' rowspan='2' colspan='1' class='banner'>{$post_timer}</td>
                        <td colspan='2' rowspan='2' class='banner'>送货</td> 
                        <td colspan='2' rowspan='2' class='banner'>收货验货:</td>    
                </tr>
                <tr></tr>
                <tr>
                        <td align='center' colspan='6' class='banner'>提示:请妥善保管客户联，质量问题请拨打投诉电话:6826777</td>    
                </tr>
                <tr>
                        <td align='center' colspan='6' class='banner'>地址:鹿寨镇五里亭  订货咨询电话:6669191</td>    
                </tr>
                <tr>
                        <td align='center' colspan='6' class='banner'>------------------------------------------------------------------------</td>    
                </tr>";
                    }
            }
            $table .= "
            </table>";
    //通过header头控制输出excel表格
                header("Pragma: public");  
            header("Expires: 0");  
            header("Cache-Control:must-revalidate, post-check=0, pre-check=0");  
            header("Content-Type:application/force-download");  
            header("Content-Type:application/vnd.ms-execl");  
            header("Content-Type:application/octet-stream");  
            header("Content-Type:application/download");;  
            header('Content-Disposition:attachment;filename="入库明细表.xls"');  
            header("Content-Transfer-Encoding:binary");  
            echo $table;
    }
// echo toChineseNumber(1234567890);//壹拾贰亿叁仟肆佰伍拾陆万柒仟捌佰玖拾圆
}
?>